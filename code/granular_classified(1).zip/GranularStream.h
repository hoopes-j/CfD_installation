/***** GranularStream *****/
#include "./GrainGenerator/GrainGenerator.h"

class GranularStream {
public:
	GranularStream() {}
	~GranularStream() {}
	
	//setup the grain generator stream
	bool setup(int sampleRate,int _numVoices) {
		this->sampleRate = sampleRate;
		this->_numVoices = 4;
		this->counterMax = 1*sampleRate;
		this->counter = 0;
		
		
		for (int i=0;i<_numVoices;i++) {
			GrainGenerator grain;
			// Load the audio file into each grain voice
			if(!grain.setup("./samples/AI.wav",sampleRate,false,false)) {
	    		return false;
			}
			grain_generators[i] = grain;
		}
		return true;
	}
	
	//gets the next audio frame from this grain generator
	//will return 0 if gate is off
	float process() {
		float out = 0;
		
		//trigger next grain generator voice
		if (counter == 0) {
			grain_generators[_voiceLocation].trigger();
		}

		//sum the ouputs of all of the grain generators
		for (int i=0;i<_numVoices;i++) {
			out += grain_generators[i].process();
		}
		
		counter++;
    	if (counter >= counterMax) {
    		counter = 0;
    		_voiceLocation++;
    		if(_voiceLocation>=_numVoices) {
    			_voiceLocation=0;
    		}
    	}
		
		return out;
	}
	
	//sets various parameters of the granular stream, applied to each individual grain generator
	void setProperties(float speed, float duration, float filePos, float onsetInSamps, float spray) {
		for (int i=0;i<_numVoices;i++) {
			this->grain_generators[i].setSpeed(speed); 
			this->grain_generators[i].setDuration(duration*sampleRate);
			this->grain_generators[i].setFilePos(filePos*sampleRate);
			this->counterMax = onsetInSamps;
			this->grain_generators[i].setSpray(spray*sampleRate);
		}
	}
private:
	float grain = 0;
	float _numVoices = 4;
	float sampleRate;
	int counter;
	int counterMax;
	int _voiceLocation;
	GrainGenerator grain_generators[4];
};