/*
 ____  _____ _        _    
| __ )| ____| |      / \   
|  _ \|  _| | |     / _ \  
| |_) | |___| |___ / ___ \ 
|____/|_____|_____/_/   \_\

http://bela.io
*/

#include <Bela.h>
#include "./GrainGenerator/GrainGenerator.h"
#include <vector>
#include "GranularStream.h"

/* NOTE: The gate on triggered by the gui were disconnected for the demo,
* so it will not work if you try to play them with the gui
*/
float hasGUI = true;

/*
 * HARDWARE GLOBALS
 */
float gPhase;
float gInverseSampleRate;
int gAudioFramesPerAnalogFrame = 0;

// Set the analog channels to read from
int gSensorInput1 = 0;
int gSensorInput2 = 1;
int gSensorInput3 = 2;
int gNumberOfSensors = 3;

int gDurationInput = 3;
int gFilePosInput = 4;
int gOnsetInput = 5;
int gSprayInput = 6;

// These define the "working range" of the SHARP IR sensor
float gMinDist = 20;
float gTriggerDist = 30;

//values for shorter rsnge senssor
// float gMinDist = 20;
// float gTriggerDist = 30;

// These will be used to print debug output
int gDebugCounter = 0;
int gDebugCounterMax;

//Sample file
std::string gFilename = "samples/AI.wav";

//level
float kAmplitude = .5;


int gCounter = 0;

int numVoices = 4;
GrainGenerator grain_generators[4]; 
int voiceLocation = 0;




//gate on for amplitude envelope
bool gate_on;
float amp_duration_ms = 10000;
float amp_duration_samps;
int envelope_ptr;

float pitch = 0;
std::vector<float> pitches = {1.0,.73,1.9,2,2.25,2.5};

bool hold;

//delay
std::vector<float> delayBuffer;
unsigned int readPointer = 0;
unsigned int writePointer = 0;


float speed;
float duration;
float filePos;
float onset_ms;
float spray;
float onset_samps;

GranularStream granStream;
GranularStream granStream2;


bool setup(BelaContext *context, void *userData)
{	
	
    /*
     * HARDWARE SETUP
     */

	// Check if analog channels are enabled
	if(context->analogFrames == 0 || context->analogFrames > context->audioFrames) {
		rt_printf("Error: this example needs analog enabled, with 4 or 8 channels\n");
		return false;
	}

	// Useful calculations
	if(context->analogFrames)
		gAudioFramesPerAnalogFrame = context->audioFrames / context->analogFrames;
	gInverseSampleRate = 1.0 / context->audioSampleRate;
	gPhase = 0.0;

	// print hardware debug info every 1/4 second
	gDebugCounterMax = .25 * context->audioSampleRate;


	/*
	 * GRANULAR SETUP
	 */
	bool granularSetupSuccess = granStream.setup(context->audioSampleRate,4) && granStream2.setup(context->audioSampleRate,4);
	
	
	speed = 1.0;
	duration = .75;
	filePos = 1.0;
	onset_samps = .02 * context->audioSampleRate;
	spray = .8;

 //   for (int i=0;i<numVoices;i++) {
	// 	GrainGenerator grain;
	// 	// Load the audio file into each grain voice
	// 	grain_generators[i] = grain;
	// 	if(!grain_generators[i].setup("./samples/AI.wav",context->audioSampleRate,false,false)) {
 //   		// rt_printf("Error loading audio file '%s'\n", gFilename.c_str());
 //   		return false;
	// 	}
	// }
	
	//delay setup
	delayBuffer.resize(.5 * context->audioSampleRate);
	readPointer = (writePointer -  (int)(0.1 * context->audioSampleRate ) + delayBuffer.size() ) % delayBuffer.size();

	return true && granularSetupSuccess;
	
}

void triggerNote(int sensor_idx) { 
	gate_on = true;
	envelope_ptr = 0;
	pitch = pitches[sensor_idx];
}


//HELPER FUNCTIONS

/*
 * Converts the three sensor inputs [cm] to a desired amplitude value to allow expressive control.
 * Inputs:
 * 		raw1, raw2, raw3: all three sensor values [cm]
 */
float amplitudeFromRaw(float raw1, float raw2, float raw3) {
	// check if all of the sensors are not triggered
	if (raw1>gTriggerDist && raw2>gTriggerDist && raw3>gTriggerDist) {
		return 0;
	}
	//otherwise, map the output of the least-valued sensor between 0 and 1, make it the global amplitude
	else {
	    float minDist = std::min(raw1, std::min(raw2, raw3));
		return map(minDist, gTriggerDist, gMinDist, 0, 1);
	}
}

std::vector<float> calcAmplitudeArray(float raw1, float raw2, float raw3) {
	std::vector<float> resultArray = {0,0,0};
	// check if all of the sensors are not triggered
	if (raw1<gTriggerDist) { 
		resultArray[0] =  map(raw1, gTriggerDist, gMinDist, 0, 1);
	}
	if (raw2<gTriggerDist) { 
		resultArray[1] =  map(raw2, gTriggerDist, gMinDist, 0, 1);
	}
	if (raw1<gTriggerDist) { 
		resultArray[2] =  map(raw3, gTriggerDist, gMinDist, 0, 1);
	}

	return resultArray;
}


/*
 * Takes an array of raw inputs, finds minimum in the array, loop through sensors
 */
float getPitchFromSensors(float *rawInputs) {

	float min = 1000;
	int activeSensorIdx = -1;

	for (int i=0; i<gNumberOfSensors; i++) {
		if (rawInputs[i] < min) {
			min = rawInputs[i];
			activeSensorIdx = i;
		}
	}
	// return the corresponding pitch
	return pitches[activeSensorIdx];
}



void render(BelaContext *context, void *userData)
{
	// SENSOR VALUES
	float ir1; 
	float ir1_dist = 0;
	float ir2;
	float ir2_dist = 0;
	float ir3;
	float ir3_dist = 0;
	float dists[3] = {-1, -1, -1};
	
	float amplitude1;
	float amplitude2;
	
	


	//retrieve data buffer from gui

	speed = 2;
	duration = .5;
	filePos = 1.5;
	onset_samps = .1 * context->audioSampleRate;
	spray = .8;

	//pass values to granulator stream
	granStream.setProperties(speed*pitches[1],duration,filePos,onset_samps,spray);
	granStream2.setProperties(speed*pitches[0],duration,filePos,onset_samps,spray);
	


	/***********************
	 *
	 * AUDIO LOOP
	 *
	 ***********************/
    for(unsigned int n = 0; n < context->audioFrames; n++) {

    	/***********************
    	 *
    	 * HARDWARE INPUT STAGE
    	 *
    	 ***********************/

    	if(gAudioFramesPerAnalogFrame && !(n % gAudioFramesPerAnalogFrame)) {
    		// read analog inputs and update the readings from sensors
    		// Depending on the sampling rate of the analog inputs, this will
    		// happen every audio frame (if it is 44100)
    		// or every two audio frames (if it is 22050)
    		ir1 = analogRead(context, n/gAudioFramesPerAnalogFrame, gSensorInput1);
    		ir2 = analogRead(context, n/gAudioFramesPerAnalogFrame, gSensorInput2);
    		ir3 = analogRead(context, n/gAudioFramesPerAnalogFrame, gSensorInput3);
    		
    		// map all raw values to distance
    		ir1_dist = map(ir1, 0.10, 0.60, 52.253, 18.92);
    		ir2_dist = map(ir2, 0.10, 0.60, 52.253, 18.92);
    		ir3_dist = map(ir3, 0.10, 0.60, 52.253, 18.92);
			
			dists[0] = ir1_dist;
			dists[1] = ir2_dist;
			dists[2] = ir3_dist;
			pitch = getPitchFromSensors(dists);
			std::vector<float> amplitudes = calcAmplitudeArray(ir1_dist,ir2_dist,ir3_dist);
			amplitude1 = amplitudes[0];
			amplitude2 = amplitudes[1];
			
			//get Granulator parameters from pots
			// float durationInputVal = analogRead(context, n/gAudioFramesPerAnalogFrame, gDurationInput);
   // 		float filePosInputVal = analogRead(context, n/gAudioFramesPerAnalogFrame, gFilePosInput);
   // 		float onsetInputVal = analogRead(context, n/gAudioFramesPerAnalogFrame, gOnsetInput);
   // 		float sprayInputVal = analogRead(context, n/gAudioFramesPerAnalogFrame, gSprayInput);
    		
    		// duration = map(durationInputVal,0,3.3/4.906,.01,1);
    		// filePos = map(filePosInputVal,0,3.3/4.906,1,1.5);
    		// onset_samps = map(onsetInputVal,0,3.3/4.906,.02,1) * context->audioSampleRate;
    		// spray = map(sprayInputVal,0,3.3/4.906,0,.99);
    	
    	}

		/*
		 * DISTANCE SENSOR VALUES (FOR DEBUGGING)
		 */
    	gDebugCounter++;
		if(gDebugCounter == gDebugCounterMax) {
			rt_printf("[sensor1: %f, sensor2 %f, sensor3 %f].   [ampltudes: 1: %f 2: %f ] \n", ir1_dist, ir2_dist, ir3_dist, amplitude1, amplitude2);
			gDebugCounter = 0;
		}
    	
    	
    	/***********************
    	 *
    	 * GRANULATION STAGE
    	 *
    	 ***********************/
    	
    	//process granulator Stream
		float in = (granStream.process()*amplitude1) + (granStream2.process()*amplitude2);
		

		/***********************
		 *
		 * EFFECTS STAGE
		 *
		 ***********************/
		float out;
		out = in;


    	for(unsigned int channel = 0; channel < context->audioOutChannels; channel++) {
			// Write the sample to every audio output channel
			audioWrite(context, n, channel, out*kAmplitude);
    	}
    	
    	
    	

    }
}



void cleanup(BelaContext *context, void *userData)
{

}
